<?php
header("Content-Type: text/html; charset=utf-8");
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>链接页面</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
        }
        .link-container {
            margin-bottom: 20px;
        }
        a {
            text-decoration: none;
            color: #3498db;
            font-size: 18px;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h1>欢迎访问链接页面</h1>
    <div class="link-container">
        <p>1. <a href="https://baozang.serv00.net/jiami" target="_blank">访问加密功能</a></p>
    </div>
    <div class="link-container">
        <p>2. <a href="http://baozang.serv00.net/blog" target="_blank">访问博客</a></p>
    </div>
    <div class="link-container">
        <p>3. <a href="https://baozang.serv00.net/chat" target="_blank">访问聊天功能</a></p>
    </div>
</body>
</html>
